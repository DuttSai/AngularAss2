import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
status:boolean=false;
data:number=0
  constructor() { }

  ngOnInit() {
  }
  show():void{
    this.status=!this.status
  }
  doget():void{
    this.data=1
  }

}
