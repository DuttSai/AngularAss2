import { Component } from '@angular/core';
import { Employee } from './employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
employee:Employee=new Employee();
employee2:Employee=new Employee();
temp:number=0
  employeeArr1:Employee[]=[
    {empId:1001,empName:"sai",empSal:20000,empDep:"javascript"},
    {empId:1002,empName:"ranjit",empSal:20000,empDep:"javascript"},
    {empId:1003,empName:"nava",empSal:20000,empDep:"javascript"}
  ]
  addEmployee(){
    this.temp=1
    //alert("Data Inserted :"+this.employee.empId+" "+this.employee.empName+" "+this.employee.empSal+" "+this.employee.empDep)
    this.employeeArr1.push(this.employee)
    console.log(JSON.stringify(this.employee))
    this.employee=new Employee()
       
  }
  delEmp(e:Employee){
    this.temp=2
    this.employeeArr1=this.employeeArr1.filter(x=>x.empId!=e.empId)
    
  }
  UpdateClick(e:Employee){
    // console.log("update clicked")
    Object.assign(this.employee2,e)
  }
  UpdateFun(emp2:Employee){
    this.delEmp(emp2)
    this.temp=3;
    this.employeeArr1.push(emp2)
    this.employee2=new Employee()
  }


}
