import { Component, OnInit } from '@angular/core';
import { Courses } from '../courses';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {
  // coursesArr: Courses[] = [
    // { id: 1, courseName: "HTML", courseDuration: 15 },
    // { id: 2, courseName: "CSS",  courseDuration: 25 },
    // { id: 3, courseName: "Bootstrap", courseDuration: 35 }
  // ]
  courseArr1:Courses[]
  courseObj: Courses = new Courses()
  courseObj1: Courses = new Courses()
  temp:number=0
  Duration:string
  errMsg:string
  constructor(private courseService:CourseService) { }

  ngOnInit() {
    this.courseService.getCourse().subscribe((x:Courses[])=>this.courseArr1=x)
  }
  AddCourse() {
    if (!this.courseObj.courseName || !this.courseObj.courseDuration) {
      return (this.temp=1)
    }
    else if(this.courseObj.courseName)
    {
    this.temp=6
    this.courseArr1.map((course)=>{
      if(course.courseName.toLowerCase()==this.courseObj.courseName.toLowerCase()){
        this.temp++
        this.errMsg="You cannot add existing Course"
      }
    })
    if(this.temp==6) {
      this.temp=0
      this.courseService.addCourse(this.courseObj)
      this.courseService.getCourse().subscribe((x:Courses[])=>this.courseArr1=x)
      this.courseObj = new Courses()
    }
  }
  }
  getDuration() {
    this.temp=2
    if(!this.courseObj1.courseName){
      this.Duration="The course  is  required !!!!!"
    }
else{
  this.Duration="Course name is INVALID "
    this.courseArr1.map(x => {
      if (x.courseName.toLowerCase() == this.courseObj1.courseName.toLowerCase()) {
        this.Duration="The Duration of " + this.courseObj1.courseName + " is " + x.courseDuration+" days"
      } 
    })  
  }  
    this.courseObj1 = new Courses()
  }

}
