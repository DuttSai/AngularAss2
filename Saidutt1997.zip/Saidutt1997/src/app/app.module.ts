import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from "@angular/forms"
import {Routes,RouterModule} from '@angular/router'
import { AppComponent } from './app.component';
import { CoursesComponent } from './courses/courses.component';
import { HttpClientModule } from '../../node_modules/@angular/common/http'
import { CoursesWithJsonComponent } from './courses-with-json/courses-with-json.component';
const appRoutes:Routes=[
  {path:'app',component:AppComponent},
  {path:'courses',component:CoursesComponent,pathMatch:"full"},
  {path:'coursesWithJSON',component:CoursesWithJsonComponent,pathMatch:"full"}
]

@NgModule({
  declarations: [
    AppComponent,
    CoursesComponent,
    CoursesWithJsonComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(appRoutes),HttpClientModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
